
%% *** fig3 Temporal evolutions of severe TCs number, MHWs frequency & SSTa ***
clc;clear
cd D:\MHW_STC_data_code\Fig3
load fig3.mat
% co_num - annual averaged severe TCs number of Co-STC-MHW during 1982-2022
% no_num - annual averaged severe TCs number of No-STC-MHW during 1982-2022
% freq2 - annual averaged global tropical (30°S-30°N) MHW frequency during 1982-2022
% ssta_g - annual averaged global SSTa (℃) during 1982-2022
% ssta_gt - annual averaged global tropical (30°S-30°N) SSTa (℃) during 1982-2022
% ann_sstasum - annual averaged SSTa of severe TCs obtained from MHWs (STC-MHW-SSTa, ℃)during 1982-2022
 
%% *** fig3a annual averaged severe TCs number of Co-STC-MHW & No-STC-MHW
figure;set(gcf,'pos',[518    95   648   788])
hh=subplot(3,1,1);set(hh,'pos',[0.1300    0.6793    0.7750    0.2157])
tc=[co_num; no_num]
h1=bar(1:41,co_num,'facecolor',[0 .45 .74],'edgecolor','none');hold on
h2=bar(1:41,no_num,0.5,'facecolor','r','edgecolor','w');
alpha(h1,0.4)
alpha(h2,0.4)

ylim([0 40])
set(gca,'xtick',[1:4:41],'xticklabel',[1982:4:2022],'fontname','Arial','fontsize',8)
ylabel('TCs #','fontname','Arial','fontsize',10)
set(hh,'linewidth',0.5)

yy=nanmean(co_num(1:20));
line([1 20],[yy yy],'color',[0.00,0.45,0.74],'LineStyle','-.','linewidth',1.5);
yy=nanmean(no_num(1:20));
line([1 20],[yy yy],'color',[0.85,0.33,0.10],'LineStyle','-.','linewidth',1.5);
yy=nanmean(co_num(22:41));
line([22 41],[yy yy],'color',[0.00,0.45,0.74],'LineStyle','-.','linewidth',1.5);
yy=nanmean(no_num(22:41));
line([22 41],[yy yy],'color',[0.85,0.33,0.10],'LineStyle','-.','linewidth',1.5);
 
fft1=['[',num2str(roundn(nanmean(co_num(1:20)),-1),'%.1f'),'/',num2str(roundn(nanmean(co_num(22:41)),-1),'%.1f'),',p<0.05]'];
fft2=['[',num2str(roundn(nanmean(no_num(1:20)),-1),'%.1f'),'/',num2str(roundn(nanmean(no_num(22:41)),-1),'%.1f'),',p<0.05]'];
text(13,35.5,fft1,'color',[0.00,0.45,0.74],'fontsize',10);
text(13,31.5,fft2,'color',[0.85,0.33,0.10],'fontsize',10);

hc=legend([h1,h2],'Co-STC-MHWs','No-STC-MHWs','location','northwest','fontname','Arial','fontsize',10);
set(hc,'box','off')
text(0.1,42,'A','fontname','Arial','fontsize',11,'fontweight','bold')

[b,bint,~,~,stats]=regress(co_num',[ones(1,41);1:41]');

ff1=['Trend=',num2str(round(b(2),2)*10),'±',num2str(round(bint(4)-b(2),2)*10),'(decade^{-1}),p<0.05']
text(24,35.5,ff1,'color',[0.00,0.45,0.74],'fontsize',10)

% [h,p]=ttest2(co_num(1:20),co_num(22:41),0.05,'both') % p<0.05
% [h,p]=ttest2(no_num(1:20),no_num(22:41),0.05,'both') % p>0.05
% V=co_num(1:41);alpha=0.05;[H,p_value]=Mann_Kendall_Modified(V,alpha) % p<0.05
%% *** fig3b MHWs Freq & TC-MHWs-SSTa during 1982-2022 ***
hold on
h1=subplot(3,1,2);set(h1,'pos',[0.1300    0.3996    0.7750    0.2157])
colororder({'k','r'})
yyaxis left

hc1=bar(1:41,ssta_g(1:41),'FaceColor',[.65 .65 .65],'EdgeColor','none'); hold on
line([0 42],[0 0],'color',[0.2 0.2 0.2],'linestyle','-','linewidth',0.01)

set(gca,'xtick',[1:4:41],'xticklabel',[1982:4:2022],'fontsize',10,'fontname','Arial')
set(gca,'YColor','k','ylim',[-0.8 0.8],'ytick',[-0.8:0.4:0.8],'yticklabel',[-0.8:0.4:0.8],'fontsize',8,'fontname','Arial')
xlim(h1,[0 42])
text(0.1,0.9,'B','fontsize',11,'fontname','Arial','fontweight','bold')
clear gssta lat latr lon lonr ssta1 t1 t2
ylabel('(°C)','fontsize',10,'fontname','Arial')

yyaxis right
xlim([0 42])
ym=1.5;
x=1:41;
[ax,hc3,hc4]=plotyy(x,freq2(1:41),x,ann_sstasum(1:41));hold on
set(hc3,'linewidth',1.2)
set(hc4,'linewidth',1.2)
set(ax(1),'xtick',[1:4:41],'xticklabel',[1982:4:2022],'ylim',[0 5],'xlim',[0 42],'ytick',[0:1:5],'yticklabel',[],'fontsize',8,'fontname','Arial')
set(ax(2),'xtick',[],'xticklabel',[],'ylim',[0 ym],'xlim',[0 42],'ytick',[],'yticklabel',[])

pos=get(ax(1),'pos')
offset = pos(3)/8
posx = pos(3) - offset/2
pos2=[pos(1) pos(2) posx+offset pos(4)]

limx1=get(ax(1),'xlim')
limx2=[limx1(1)   limx1(1) + 1.2*(limx1(2)-limx1(1))]
ax(1)=axes('Position',pos,'box','off',...
   'Color','none','XColor','k','YColor','r',...   
   'xtick',[],'xticklabel',[],'xlim',limx1,'ylim',[0 5],'yaxislocation','right');
ax(2)=axes('Position',pos2,'box','off',...
   'Color','none','XColor','none','YColor',[0.00,0.45,0.74],...   
   'xtick',[],'xticklabel',[],'xlim',limx2,'ylim',[0 ym],'yaxislocation','right');
set(hc3,'color','r')
set(hc4,'color',[0.00,0.45,0.74])

set(ax(1),'ytick',[0:1:5],'yticklabel',[0:1:5],'fontsize',8,'fontname','Arial')
set(ax(2),'ytick',[0:ym/5:ym],'yticklabel',[0:ym/5:ym],'fontsize',8,'fontname','Arial')
yy1=ylabel(ax(1),'(Count)','fontsize',10,'fontname','Arial')
yy2=ylabel(ax(2),'(°C)','fontsize',10,'fontname','Arial')
set(yy1,'pos',[42    5.9    0])
set(yy2,'pos',[50.5    1.7    0])

[r p]=corrcoef(co_num,freq2,'Alpha',0.05)
[r p]=corrcoef(ssta_gt,ann_sstasum,'Alpha',0.05)
[r p]=corrcoef(ssta_gt,freq2,'Alpha',0.05)
[r p]=corrcoef(freq2,ann_sstasum,'Alpha',0.05)
text(25,1.35,['R(L1,L2)=',num2str(round(r(2),2)),',p<0.05'],'color','k','fontname','Arial','fontsize',10)
clear alpha
set(h1,'linewidth',0.5)
%%
[b,bint,~,~,stats]=regress(freq2,[ones(1,41);1:41]');
ff2=['L1:MHWs Freq']
ff4=['L1:Trend=',num2str(round(b(2),2)*10,'%.1f'),'±',num2str(round(bint(4)-b(2),2)*10,'%.1f'),' (Count\cdotdecade^{-1}),p<0.05']

[b,bint,~,~,stats]=regress(ann_sstasum',[ones(1,41);1:41]');
ff3=['L2:STC-MHWs-SSTa']
ff5=['L2:Trend=',num2str(round(b(2),3)*10),'±',num2str(round(bint(4)-b(2),3)*10),' (°C\cdotdecade^{-1}),p<0.05']

hc=legend([hc3 hc4],{ff2,ff3},...
    'location','northwest','fontname','Arial','FontSize',10)
set(hc,'box','off')

text(20,0.3,ff4,'color','k','fontname','Arial','fontsize',10)
text(20,0.15,ff5,'color','k','fontname','Arial','fontsize',10)
%%
% cd D:\MHW_STC_data_code\Figure\
% print('-depsc2','-r300','Fig3')
% print('-dtiffn','-r300','Fig3')
