function [c]=ssmooth(x,i,m,l) %x�Ǳ�����i����Ҫƽ����ά����m��ƽ���ĵ���������Ϊ������l�Ƿ�nanmean��l=1����ȥ��nanƽ��
if l==1
    ll=['omitnan'];
else
    ll=['includenan'];
end

[i1,i2,i3,i4]=size(x);

c=nan(i1,i2,i3,i4);

if i==1
    for it=1:i4
        for iz=1:i3
            for iy=1:i2
                x0=reshape(squeeze(x(:,iy,iz,it)),i1,1);
                a=find(~isnan(x0));
                if ~isempty(a)
                    for ii=1+(m-1)/2:i1-(m-1)/2
                        c(ii,iy,iz,it)=mean(x0(ii-(m-1)/2:ii+(m-1)/2),1,ll);
                    end
                    c(1,iy,iz,it)=x0(1);
                    c(a(end),iy,iz,it)=x0(a(end));
                end
            end
        end
    end
elseif i==2
    for it=1:i4
        for iz=1:i3
            for ix=1:i1
                x0=reshape(squeeze(x(ix,:,iz,it)),i2,1);
                a=find(~isnan(x0));
                if ~isempty(a)
                    for ii=1+(m-1)/2:i2-(m-1)/2
                        c(ix,ii,iz,it)=mean(x0(ii-(m-1)/2:ii+(m-1)/2),1,ll);
                    end
                    c(ix,1,iz,it)=x0(1);
                    c(ix,a(end),iz,it)=x0(a(end));
                end
            end
        end
    end
elseif i==3
    for it=1:i4
        for iy=1:i2
            for ix=1:i1
                x0=reshape(squeeze(x(ix,iy,:,it)),i3,1);
                a=find(~isnan(x0));
                for ii=1+(m-1)/2:i3-(m-1)/2
                    c(ix,iy,ii,it)=mean(x0(ii-(m-1)/2:ii+(m-1)/2),1,ll);
                end
                c(ix,iy,1,it)=x0(1);
                c(ix,iy,a(end),it)=x0(a(end));
            end
        end
    end
elseif i==4
    for iz=1:i3
        for iy=1:i2
            for ix=1:i1
                x0=reshape(squeeze(x(ix,iy,iz,:)),i4,1);
                a=find(~isnan(x0));
                if ~isempty(a)
                    for ii=1+(m-1)/2:i4-(m-1)/2
                        c(ix,iy,iz,ii)=mean(x0(ii-(m-1)/2:ii+(m-1)/2),1,ll);
                    end
                    c(ix,iy,iz,1)=x0(1);
                    c(ix,iy,iz,a(end))=x0(a(end));
                end
            end
        end
    end
end
end