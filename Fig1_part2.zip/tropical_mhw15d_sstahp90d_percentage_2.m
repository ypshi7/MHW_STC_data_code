close all;clear all;clc;
cd D:\MHW_STC_data_code\Fig1
%% 读取单个数据的经纬度和时间范围
load gsmhw_freq_trend.mat
load gmhw_Freq.mat
%%
load gmhw_Freq.mat
load gmhw_Dur.mat
y1=find(lat>=-30 & lat<=30);
ly1=length(y1);
freq=gmhw_mean_freq(:,y1);
dur=gmhw_mean_dur(:,y1);
freq1=reshape(freq,720*ly1,1);
dur1=reshape(dur,720*ly1,1);
a=find(~isnan(freq1) & ~isnan(dur1));
freq2=freq1(a);
dur2=dur1(a);
corr(freq1(a),dur1(a))
%%
load gsmhw_freq.mat
load gmmhw_freq.mat
load glmhw_freq.mat
load gxlmhw_freq.mat
%%
lon0=[0:0.5:360];
lat0=[-90:0.5:90];
dx=zeros(length(lon),length(lat));
for i=1:length(lat)
    for j=1:length(lon)
    dx(j,i)=m_lldist([lon0(j) lon0(j+1)],[lat(i),lat(i)])*1e3;
    end
end
clear i j
dy=m_lldist([lon(1),lon(1)],[lat0(1),lat0(2)])*1e3;
ds=dx.*dy;
%%
dsm=repmat(ds,1,1,41);
ds_s=dsm;
ds_s(isnan(gsmhw_freq))=nan;
ds_m=dsm;
ds_m(isnan(gmmhw_freq))=nan;
ds_l=dsm;
ds_l(isnan(glmhw_freq))=nan;
ds_xl=dsm;
ds_xl(isnan(gxlmhw_freq))=nan;

y1=find(lat>=-30 & lat<=30);
gsmhw_freq_ss=squeeze(sum(sum(gsmhw_freq(:,y1,:).*ds_s(:,y1,:),1,'omitnan'),2,'omitnan'));
gmmhw_freq_ss=squeeze(sum(sum(gmmhw_freq(:,y1,:).*ds_m(:,y1,:),1,'omitnan'),2,'omitnan'));
glmhw_freq_ss=squeeze(sum(sum(glmhw_freq(:,y1,:).*ds_l(:,y1,:),1,'omitnan'),2,'omitnan'));
gxlmhw_freq_ss=squeeze(sum(sum(gxlmhw_freq(:,y1,:).*ds_xl(:,y1,:),1,'omitnan'),2,'omitnan'));

gsmhw_freq_ss_p1=sum(gsmhw_freq_ss(1:20),'omitnan');
gmmhw_freq_ss_p1=sum(gmmhw_freq_ss(1:20),'omitnan');
glmhw_freq_ss_p1=sum(glmhw_freq_ss(1:20),'omitnan');
gxlmhw_freq_ss_p1=sum(gxlmhw_freq_ss(1:20),'omitnan');
gsmhw_freq_ss_p2=sum(gsmhw_freq_ss(22:41),'omitnan');
gmmhw_freq_ss_p2=sum(gmmhw_freq_ss(22:41),'omitnan');
glmhw_freq_ss_p2=sum(glmhw_freq_ss(22:41),'omitnan');
gxlmhw_freq_ss_p2=sum(gxlmhw_freq_ss(22:41),'omitnan');

gsmhw_freq_sstd_p1=std(gsmhw_freq_ss(1:20),'omitnan');
gmmhw_freq_sstd_p1=std(gmmhw_freq_ss(1:20),'omitnan');
glmhw_freq_sstd_p1=std(glmhw_freq_ss(1:20),'omitnan');
gxlmhw_freq_sstd_p1=std(gxlmhw_freq_ss(1:20),'omitnan');
gsmhw_freq_sstd_p2=std(gsmhw_freq_ss(22:41),'omitnan');
gmmhw_freq_sstd_p2=std(gmmhw_freq_ss(22:41),'omitnan');
glmhw_freq_sstd_p2=std(glmhw_freq_ss(22:41),'omitnan');
gxlmhw_freq_sstd_p2=std(gxlmhw_freq_ss(22:41),'omitnan');

gmhw_freq_ss=gsmhw_freq_ss_p1+gmmhw_freq_ss_p1+glmhw_freq_ss_p1+gxlmhw_freq_ss_p1+gsmhw_freq_ss_p2+gmmhw_freq_ss_p2+glmhw_freq_ss_p2+gxlmhw_freq_ss_p2;

freq_ss_ratio=nan(4,2);
freq_ss_ratio(1,1)=gsmhw_freq_ss_p1./gmhw_freq_ss*100;
freq_ss_ratio(1,2)=gsmhw_freq_ss_p2./gmhw_freq_ss*100;
freq_ss_ratio(2,1)=gmmhw_freq_ss_p1./gmhw_freq_ss*100;
freq_ss_ratio(2,2)=gmmhw_freq_ss_p2./gmhw_freq_ss*100;
freq_ss_ratio(3,1)=glmhw_freq_ss_p1./gmhw_freq_ss*100;
freq_ss_ratio(3,2)=glmhw_freq_ss_p2./gmhw_freq_ss*100;
freq_ss_ratio(4,1)=gxlmhw_freq_ss_p1./gmhw_freq_ss*100;
freq_ss_ratio(4,2)=gxlmhw_freq_ss_p2./gmhw_freq_ss*100;
%%
load('gssta_std.mat')
load('gssta_hp90d_std.mat')

r=gssta_hp90d_std./gssta_std*100;
p=sum(gsmhw_freq,3,'omitnan')./sum(gsmhw_freq+gmmhw_freq+glmhw_freq+gxlmhw_freq,3,'omitnan')*100;

%%
ro=r(:,y1,:);
% ro_sm=ssmooth(ssmooth(ssmooth(ssmooth(ro,1,3,1),2,3,1),1,3,1),2,3,1);
rr=reshape(ro,720*ly1,1);
po=p(:,y1,:);
% po_sm=ssmooth(ssmooth(ssmooth(ssmooth(po,1,3,1),2,3,1),1,3,1),2,3,1);
pp=reshape(po,720*ly1,1);
%%
proj = {... Azimuthal Projections

'Stereographic'; % 1 Polar regions

'Orthographic'; % 2 resembles the globe

'Azimuthal Equal-area'; % 3

'Azimuthal Equidistant'; % 4

'Gnomonic'; % 5

'Satellite'; % 6

... Cylindrical Projections

'Mercator'; % 7

'Miller Cylindrical'; % 8

'Equidistant Cylicndrical'; % 9

'Oblique Mercator'; % 10

'Transverse Mercator'; % 11

'UTM'; % 12

'Sinusoidal'; % 13

'Gall-Peters'; % 14

... Conic Projections

'Albers Equal-Area Conic'; % 15

'Lambert Conformal Conic'; % 16

... Global Projections

'Hammer-Aitoff'; % 17

'Mollweide'; % 18

'Robinson'}; % 19
[x y]=meshgrid(lon,lat);
load('C:\Program Files\Polyspace\R2020a\toolbox\matlab_myfunction\colorbar\temp_19lev.txt');
mycmap=load ('C:\Program Files\Polyspace\R2020a\toolbox\matlab_myfunction\colorbar\WhiteBlueGreenYellowRed.txt');
%%
figure;set(gcf,'pos',[1 1 18 15])
h1=subplot(322)
set(h1,'position',[0.76,0.73,0.22,0.22]);
scatter(dur2,freq2,5,[0.1 0.1 0.1],'filled')
hold on
[r1,p1]=corr(dur2,freq2)
% yp=polyfit(dur2,freq2,1);
% y1=polyval(yp,[0:10:50]);
% plot([0:10:50],y1,'color',mycmap(230,:),'linestyle','-','linewi',2.5)
set(gca,'xlim',[0 50]);
set(gca,'xtick',[0:10:50],'xticklabel',[0:10:50],'fontsize',8, ...
    'fontname','Arial');
set(gca,'ylim',[0.5 4]);
set(gca,'ytick',[0.5:1:4],'yticklabel',[0.5:1:4],'fontsize',8, ...
   'fontname','Arial');
xlabel('MHW Dur (day)','fontsize',8,'fontname','Arial')
ylabel('MHW Freq (count)','fontsize',8,'fontname','Arial')
text(24,3.5,['r=',num2str(roundn(r1,-2)),', p<0.05'],'fontname','Arial',...
'fontsize',8,'color','k');
text(1,4.2,'B','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
set(gca,'linewidth',0.5)
box on
%%
h1=subplot(324)
set(h1,'position',[0.76,0.41,0.22,0.22]);
h=bar(freq_ss_ratio,'stacked','DisplayName','idurn_all')
set(h(1),'facecolor',temp_19lev(3,:))
set(h(2),'facecolor',temp_19lev(16,:))
set(gca,'xlim',[0 5]);
set(gca,'xtick',[1:1:4],'xticklabel',{'5-15','15-30','30-60','>=60'},'fontsize',8, ...
    'fontname','Arial');
set(gca,'ylim',[0 0.8]*100);
set(gca,'ytick',[0:0.2:0.8]*100,'yticklabel',[0:0.2:0.8]*100,'fontsize',8, ...
   'fontname','Arial');
% title('1982-2000 30\circS-30\circN','fontname','Arial',...
% 'fontsize',8,'color','k','fontweight','bold');
text(0.1,86,'D','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
text(0.65,55,'44%','fontname','Arial','fontsize',8,'color','k');
text(0.65,15,'28%','fontname','Arial','fontsize',8,'color','k');
text(2.55,55,'p<0.05','fontname','Arial','fontsize',8,'color','k');
xlabel('MHW Dur (day)','fontsize',8,'fontname','Arial')
ylabel('Probability (%)','fontsize',8,'fontname','Arial')
set(gca,'linewidth',0.5)
%%
h1=subplot(326)
set(h1,'position',[0.76,0.09,0.22,0.22]);
scatter(rr,pp,5,[0.1 0.1 0.1],'filled')
hold on
a=find(~isnan(rr));
rc=rr(a);
pc=pp(a);
[r1,p1]=corr(rc,pc)
yp=polyfit(rc,pc,1);
y1=polyval(yp,[25:10:85]);
plot([25:10:85],y1,'color',mycmap(230,:),'linestyle','-','linewi',2)
set(gca,'xlim',[20 90]);
set(gca,'xtick',[20:20:90],'xticklabel',[20:20:90],'fontsize',8, ...
    'fontname','Arial');
set(gca,'ylim',[20 110]);
set(gca,'ytick',[20:20:110],'yticklabel',[20:20:110],'fontsize',8, ...
   'fontname','Arial');
xlabel('STD(SSTa_{F<90d})/STD(SST) (%)','fontsize',8,'fontname','Arial')
ylabel('N(MHWs_{D<=15d})/N(MHWs) (%)','fontsize',8,'fontname','Arial')
text(55,35,['r=',num2str(roundn(r1,-2)),', p<0.05'],'fontname','Arial',...
'fontsize',8,'color','k');
text(21,116,'F','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
set(gca,'linewidth',0.5)
box on
%%
h1=subplot(321)
set(h1,'position',[0.06,0.7,0.54,0.28]);
cla
m_proj('Equidistant Cylindrical','lon',[0 360],'lat',[-60 60]);
m_contourf(x,y,gmhw_trend_freq',[-0.2:0.02:0.2],'linestyle','none');
shading flat
hold on
gmhw_p1_freq=nan(720,360);
gmhw_p1_freq(1:4:end,1:4:end)=gmhw_p_freq(1:4:end,1:4:end);
a1=find(gmhw_p1_freq'>0.05);
m_plot(x(a1),y(a1),'.','color','k','Markersize',1.5);
colormap(gca,temp_19lev)
h=colorbar('position',[0.615 0.74 0.01 0.2],'Ticks',[-0.2:0.1:0.2],'fontsize',8,'fontname','Arial')
set(get(h,'title'),'string','(count yr^{-1})','position',[35 45],'fontsize',8,'fontname','Arial','rotation',90);
m_coast('patch',[0.8 0.8 0.8]);
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',8,...
'xtick',[0:60:360],'Xticklabel',[0:60:360],...
'ytick',[-60:30:60],'Yticklabel',[-60:30:60],'linewidth',0.5);
% title('MHW(5-15d) Freq Trend','fontname','Arial',...
% 'fontsize',20,'color','k','fontweight','bold');
m_text(5,68,'A','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
caxis([-0.2 0.2])
set(gca,'linewidth',0.5)
%%
h1=subplot(323)
set(h1,'position',[0.06,0.38,0.54,0.28]);
cla
m_proj('Equidistant Cylindrical','lon',[0 360],'lat',[-60 60]);
m_contourf(x,y,gsmhw_freq_trend',[-0.2:0.02:0.2],'linestyle','none');
shading flat
hold on
gsmhw_freq_p1=nan(720,360);
gsmhw_freq_p1(1:4:end,1:4:end)=gsmhw_freq_p(1:4:end,1:4:end);
a2=find(gsmhw_freq_p1'>0.05);
m_plot(x(a2),y(a2),'.','color','k','Markersize',1.5);
colormap(gca,temp_19lev)
h=colorbar('position',[0.615 0.42 0.01 0.2],'Ticks',[-0.2:0.1:0.2],'fontsize',8,'fontname','Arial')
set(get(h,'title'),'string','(count yr^{-1})','position',[35 45],'fontsize',8,'fontname','Arial','rotation',90);
m_coast('patch',[0.8 0.8 0.8]);
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',8,...
'xtick',[0:60:360],'Xticklabel',[0:60:360],...
'ytick',[-60:30:60],'Yticklabel',[-60:30:60],'linewidth',0.5);
% title('MHW(5-15d) Freq Trend','fontname','Arial',...
% 'fontsize',20,'color','k','fontweight','bold');
m_text(5,68,'C','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
caxis([-0.2 0.2])
set(gca,'linewidth',0.5)
%%
h1=subplot(325)
set(h1,'position',[0.06,0.06,0.54,0.28]);
cla
m_proj('Equidistant Cylindrical','lon',[0 360],'lat',[-60 60]);
m_contourf(x,y,p',[40:5:100],'linestyle','none');
shading flat
hold on
m_contour(x,y,ssmooth(ssmooth(r',1,3,1),2,3,1),[0:5:50],'k','linestyle','-.','linewidth',1);
m_contour(x,y,ssmooth(ssmooth(r',1,3,1),2,3,1),[50:5:100],'k','linestyle','-','linewidth',1);
% m_contour(x,y,gmhw_Days',[20 20],'k','linestyle','-','linewidth',2);
% m_contour(x,y,ssmooth(ssmooth(ssmooth(ssmooth(r',1,3,1),2,3,1),1,3,1),2,3,1),[0:5:100],'k','linestyle','-','linewidth',1.5);
colormap(gca,mycmap(1:254,:))
h=colorbar('position',[0.615 0.10 0.01 0.2],'Ticks',[40:20:100],'fontsize',8,'fontname','Arial')
set(get(h,'title'),'string','(%)','position',[35 45],'fontsize',8,'fontname','Arial','rotation',90);
m_coast('patch',[0.8 0.8 0.8]);
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',8,...
'xtick',[0:60:360],'Xticklabel',[0:60:360],...
'ytick',[-60:30:60],'Yticklabel',[-60:30:60],'linewidth',0.5);
% title('1982-2019 MHW Annual Days','fontname','Arial',...
% 'fontsize',20,'color','k','fontweight','bold');
m_text(5,68,'E','fontname','Arial','fontweight','bold','fontsize',11,'color','k');
caxis([40 100])
set(gca,'linewidth',0.5)
%%
cd D:\MHW_STC_data_code\Figure\
set(gcf,'units','centimeters','Position',[1 1 18 15])
set(gcf,'paperunits','centimeters','PaperPosition',[1.5 2 18 15])
print('-depsc2','-r300','Fig1')
print('-dtiffn','-r300','Fig1')
%%

